import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Settings, Home, Pencil, BookOpen, FileText, Table2 } from 'lucide-react';
import SettingsModal from './SettingsModal';
import { cn } from '@/lib/utils';
import { useState, useRef, useEffect } from 'react';
import SpaceModal from './spaces/SpaceModal';
import Tooltip from './Tooltip';
import useFreshlyUpdated from '@/lib/useFreshlyUpdated';
import PostUpdateToast from './PostUpdateToast';
import { pendingReleaseCount } from '@/data/changelog';

// NOTE: previous versions polled the local index.html for an etag change as a
// PWA-style "new build available" signal. Quillosofi is a desktop app — that
// fetch ran against `file://` and produced spurious ERR_FILE_NOT_FOUND errors
// in DevTools. Update detection now lives entirely in the Update tab via
// electron-updater + GitHub releases. The badge dot driven by the Settings
// gear is wired to the desktop updater state instead.

// v0.4.46 — The Pure Writing Refactor. The combined gear+brain glyph and
// the separate AI Settings entry point have been removed. The single
// Settings gear on the right side of the rail is now the only entry point
// since the AI layer no longer exists.

export default function SpaceRail({ spaces, onSpaceCreated }) {
  const location = useLocation();
  const navigate = useNavigate();
  const [showSpaceModal, setShowSpaceModal] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [settingsInitialTab, setSettingsInitialTab] = useState('general');
  const [editingSpace, setEditingSpace] = useState(null);
  const [contextMenu, setContextMenu] = useState(null);
  const menuRef = useRef(null);
  const scrollRef = useRef(null);

  // Freshly-updated dot: lights up after a version bump, until the user opens
  // the Update tab. Independent from the in-app updater badge below.
  const { freshlyUpdated, fromVersion, toVersion, dismiss: dismissFreshlyUpdated } = useFreshlyUpdated();

  // v0.5.72 — mobile-style green pill on the Settings gear, counting how
  // many releases the user is behind. Count is derived from the bundled
  // changelog (pendingReleaseCount(installed, latest)), so a user who is
  // 3 versions behind sees "3" rather than just "1". Falls back to 0 on
  // web/dev where the updater bridge isn't present.
  const [updateBadge, setUpdateBadge] = useState(0);
  useEffect(() => {
    if (!window.quillosofi?.updates) return;
    let unsub = null;
    const computeBadge = (s) => {
      if (!s) return 0;
      const ready = s.status === 'available' || s.status === 'downloaded';
      if (!ready) return 0;
      const n = pendingReleaseCount(s.currentVersion, s.latestVersion);
      // Always show at least 1 if an update is actually pending — even if
      // the changelog is missing entries for whatever reason, the user
      // should still see a badge.
      return n > 0 ? n : 1;
    };
    (async () => {
      try {
        const s = await window.quillosofi.updates.status();
        setUpdateBadge(computeBadge(s));
      } catch (_) {}
      unsub = window.quillosofi.updates.onState((p) => {
        setUpdateBadge(computeBadge(p));
      });
    })();
    return () => { if (unsub) unsub(); };
  }, []);

  // Listen for the global keybind trigger from <Layout /> so Ctrl+, opens
  // Settings even when the user is focused elsewhere. (v0.4.46: the
  // separate Ctrl+; → AI Settings binding was removed alongside the AI
  // layer.)
  useEffect(() => {
    const onOpenSettings = () => setShowSettings(true);
    window.addEventListener('quillosofi:open-settings', onOpenSettings);
    return () => {
      window.removeEventListener('quillosofi:open-settings', onOpenSettings);
    };
  }, []);

  const scrollStyles = `
    .spacerail-scroll { scrollbar-width: none; -ms-overflow-style: none; }
    .spacerail-scroll::-webkit-scrollbar { display: none; }
  `;

  const handleSpaceContextMenu = (e, space) => {
    e.preventDefault();
    const rect = e.currentTarget.getBoundingClientRect();
    setContextMenu({ space, x: rect.right, y: rect.top + rect.height });
  };

  const isHome = location.pathname === '/';
  const isQuillibrary = location.pathname === '/quillibrary' || location.pathname === '/canvas-vault';
  // Canvas + Sheets get full editor hubs in v0.4.7 — dedicated routes with
  // multi-doc tabs and Resume Last. Quillibrary remains pure storage.
  const isCanvasHub = location.pathname === '/canvas' || location.pathname.startsWith('/canvas/');
  const isSheetsHub = location.pathname === '/sheets' || location.pathname.startsWith('/sheets/');
  const activeSpaceId = location.pathname.startsWith('/space/') ? location.pathname.split('/space/')[1] : null;

  const railBtn = (active) => cn(
    'w-11 h-11 md:w-9 md:h-9 rounded-[18px] flex items-center justify-center transition-all duration-150 cursor-pointer active:scale-90 active:brightness-75',
    active ? 'bg-primary rounded-[10px]' : 'bg-[hsl(228,7%,42%)] hover:bg-primary hover:rounded-[10px]'
  );

  return (
    <>
      <style>{scrollStyles}</style>
      <div className="flex flex-row items-center h-[52px] w-full shrink-0 gap-0 chalk-shell-board border-b border-[hsl(var(--chalk-white-faint)/0.3)]">

        {/* Left fixed buttons: Quillounge -> Canvas -> Sheets -> Quillibrary -> divider -> (AI: Research, Chat) */}
        <div className="flex items-center gap-2 px-3 shrink-0">
          <Tooltip text="Quillounge — Home">
            <Link to="/" className="[touch-action:manipulation]">
              <div className={railBtn(isHome)}>
                <Home className="h-4 w-4 text-white" />
              </div>
            </Link>
          </Tooltip>

          <Tooltip text="Canvas — writing editor">
            <button
              onClick={() => navigate('/canvas')}
              style={{ touchAction: 'manipulation' }}
              className={railBtn(isCanvasHub)}
            >
              <FileText className="h-4 w-4 text-white" />
            </button>
          </Tooltip>

          <Tooltip text="Sheets — spreadsheet editor">
            <button
              onClick={() => navigate('/sheets')}
              style={{ touchAction: 'manipulation' }}
              className={railBtn(isSheetsHub)}
            >
              <Table2 className="h-4 w-4 text-white" />
            </button>
          </Tooltip>

          <Tooltip text="Quillibrary — canvases, sheets, and spaces">
            <button
              onClick={() => navigate('/quillibrary')}
              style={{ touchAction: 'manipulation' }}
              className={railBtn(isQuillibrary)}
            >
              <BookOpen className="h-4 w-4 text-white" />
            </button>
          </Tooltip>

          <div className="h-6 w-px bg-[hsl(220,7%,25%)] mx-1" />
        </div>

        {/* Scrollable spaces section — always visible in v0.4.46+, since
            spaces are now a pure writing organisation feature. */}
        <div
          ref={scrollRef}
          className="flex items-center gap-2 overflow-x-auto spacerail-scroll flex-1 px-2"
          style={{ WebkitOverflowScrolling: 'touch', overflowX: 'auto', touchAction: 'pan-x' }}
          onPointerDown={(e) => {
            const el = scrollRef.current;
            if (!el) return;
            const startX = e.clientX;
            const startScroll = el.scrollLeft;
            let moved = false;
            const onMove = (ev) => {
              const dx = startX - ev.clientX;
              if (Math.abs(dx) > 4) moved = true;
              el.scrollLeft = startScroll + dx;
            };
            const onUp = () => {
              window.removeEventListener('pointermove', onMove);
              window.removeEventListener('pointerup', onUp);
            };
            window.addEventListener('pointermove', onMove);
            window.addEventListener('pointerup', onUp);
          }}
        >
          {spaces.map(s => {
            const isActive = activeSpaceId === s.id;
            const isImg = s.emoji && (s.emoji.startsWith('http') || s.emoji.startsWith('/'));
            return (
              <Tooltip key={s.id} text={s.name}>
                <Link to={`/space/${s.id}`} onContextMenu={(e) => handleSpaceContextMenu(e, s)} className="flex items-center [touch-action:manipulation]">
                  <div className={cn(
                    "w-11 h-11 md:w-9 md:h-9 rounded-[18px] flex items-center justify-center text-lg transition-all duration-150 cursor-pointer active:scale-90 active:brightness-75 overflow-hidden",
                    isActive ? "bg-primary rounded-[10px]" : "bg-[hsl(228,7%,42%)] hover:bg-primary/80 hover:rounded-[10px]"
                  )}>
                    {isImg
                      ? <img src={s.emoji} alt={s.name} className="w-6 h-6 object-cover rounded" />
                      : (s.emoji || '📁')
                    }
                  </div>
                </Link>
              </Tooltip>
            );
          })}
        </div>

        {/* Right fixed buttons: Settings */}
        <div className="flex items-center gap-2 px-3 shrink-0">
          <Tooltip text={updateBadge > 0
            ? `${updateBadge} update${updateBadge === 1 ? '' : 's'} available — Settings (Ctrl+,)`
            : 'Settings (Ctrl+,)'}>
            <button onClick={() => setShowSettings(true)}
              style={{ touchAction: 'manipulation' }}
              className="relative w-11 h-11 md:w-9 md:h-9 shrink-0 rounded-[18px] bg-[hsl(228,7%,42%)] hover:bg-primary hover:rounded-[10px] flex items-center justify-center transition-all duration-150 text-[hsl(220,7%,80%)] hover:text-white active:scale-90 active:brightness-75">
              <Settings className="h-4 w-4" />
              {updateBadge > 0 ? (
                /* Mobile-style notification pill — green, counted, soft glow.
                   Sits at top-right of the gear, mirrors how iOS/Android render
                   app-icon badges. The freshlyUpdated dot is suppressed when a
                   pending update is showing so we don't double-up indicators. */
                <span
                  className="absolute -top-1.5 -right-1.5 min-w-[18px] h-[18px] px-1 rounded-full bg-green-400 text-[10px] font-bold text-[hsl(223,7%,12%)] flex items-center justify-center border-2 border-[hsl(223,7%,16%)] shadow-[0_0_0_1px_rgba(34,197,94,0.35),0_0_8px_rgba(34,197,94,0.45)] tabular-nums leading-none"
                  aria-label={`${updateBadge} update${updateBadge === 1 ? '' : 's'} available`}
                >
                  {updateBadge > 99 ? '99+' : updateBadge}
                </span>
              ) : freshlyUpdated && (
                <span className="absolute -top-1 -right-1 h-3.5 w-3.5 rounded-full bg-green-400 border-2 border-[hsl(223,7%,16%)]" />
              )}
            </button>
          </Tooltip>
        </div>

      </div>

      {showSpaceModal && (
        <SpaceModal
          initialSpace={editingSpace}
          onClose={() => { setShowSpaceModal(false); setEditingSpace(null); }}
          onSave={(s) => { onSpaceCreated(s); setShowSpaceModal(false); setEditingSpace(null); navigate(`/space/${s.id}`); }}
        />
      )}
      {showSettings && <SettingsModal onClose={() => { setShowSettings(false); setSettingsInitialTab('general'); }} initialTab={settingsInitialTab} updateCount={updateBadge} freshlyUpdated={freshlyUpdated} onUpdateTabSeen={dismissFreshlyUpdated} />}

      {freshlyUpdated && toVersion && (
        <PostUpdateToast
          fromVersion={fromVersion}
          toVersion={toVersion}
          onDismiss={dismissFreshlyUpdated}
          onOpenChangelog={() => {
            setSettingsInitialTab('update');
            setShowSettings(true);
            dismissFreshlyUpdated();
          }}
        />
      )}
      {contextMenu && (
        <>
          <div className="fixed inset-0 z-[60]" onClick={() => setContextMenu(null)} />
          <div
            ref={menuRef}
            className="fixed z-[70] bg-[hsl(220,8%,15%)] border border-[hsl(225,9%,12%)] rounded-lg shadow-2xl p-1.5 min-w-40"
            style={{ top: contextMenu.y + 4, left: contextMenu.x - 160 }}
            onClick={() => setContextMenu(null)}
          >
            <button
              onClick={() => { setEditingSpace(contextMenu.space); setShowSpaceModal(true); }}
              className="w-full flex items-center gap-2.5 px-3 py-2 rounded text-xs text-[hsl(220,7%,80%)] hover:bg-[hsl(228,7%,27%)] hover:text-white transition-colors text-left"
            >
              <Pencil className="h-3.5 w-3.5 text-primary" /> Edit Space
            </button>
          </div>
        </>
      )}
    </>
  );
}
