/*
 * Quillosofi changelog — bundled with the app at build time.
 *
 * Each entry corresponds to a tagged release. The Update tab's Changelog
 * panel reads from here and displays entries up through the installed
 * version (so an older build never shows changes that don't exist in it).
 *
 * Conventions:
 *   - `version`  must match the SemVer in package.json for that release.
 *   - `date`     ISO date string. Use the actual tag date.
 *   - `tagline`  one-liner. Shows next to the version chip.
 *   - `changes`  array of strings. Each is a single user-facing change.
 *                Keep them concise — the panel renders them as bullets.
 *
 * Newest first. The component reverses-by-version safely either way, but
 * keeping the source ordered makes diffs readable.
 */
export const CHANGELOG = [
  {
    version: '0.5.8',
    date: '2026-05-07',
    tagline: 'A real Word-style Paragraph dialog lives next to the View button now \u2014 indents, spacing, line spacing, page-break-before, hyphenation, and a full multilingual Asian Typography tab that adapts to whichever CJK or other Asian script you\u2019re actually writing in.',
    changes: [
      'New \u00b6 Paragraph button on the Canvas toolbar, parked right next to View. Opens a Word-faithful three-tab modal: Indents and Spacing, Line and Page Breaks, Asian Typography. The visual layout, tab order, and field labels mirror Word\u2019s Format \u2192 Paragraph dialog so muscle memory transfers cleanly. Apply scope is the current selection if you have one, otherwise the paragraph(s) the cursor is sitting in \u2014 same semantic Word uses.',
      'Tab 1: Indents and Spacing. Alignment (Left / Centered / Right / Justified), Left and Right indents in inches with 0.01\u2033 steppers, Special indent (none / First line / Hanging) with a By-value field, Spacing Before and After in points, Line spacing (Single / 1.5 / Double / At least / Exactly / Multiple) with the corresponding At-value field that enables only when the chosen mode needs it, plus the \u201cDon\u2019t add space between paragraphs of the same style\u201d toggle. Outline level, Mirror indents, Auto-adjust right indent, Collapsed by default, and Snap to grid render in the layout but stay disabled \u2014 they need plumbing that arrives with full flow-pagination in v0.6.0.',
      'Tab 2: Line and Page Breaks. Page break before and Don\u2019t hyphenate are wired up live; Widow/Orphan, Keep with next, Keep lines together, Suppress line numbers, and Tight wrap stay disabled with a tooltip pointing at v0.6.0 (they all depend on cross-page flow tracking that hasn\u2019t been written yet).',
      'Tab 3: Asian Typography \u2014 multilingual, not Japanese-only. The toggles map to native browser CSS properties (line-break: strict for kinsoku, word-break: break-all for Latin mid-word wrap, hanging-punctuation for burasagari, text-spacing-trim for start-of-line punctuation compression, text-autospace for ideograph-alpha and ideograph-numeric spacing). The browser applies the right rules for whatever script the text is written in \u2014 Chinese, Japanese, Korean, and other Asian scripts all benefit from the same toggles instead of being shoehorned into Japanese-specific behavior.',
      'Live preview pane at the bottom of the dialog reflects every change as you make it \u2014 alignment, indents, special indent, before/after spacing, line spacing, hyphenation, and the Latin wrap toggle all show in a real font sample with CJK characters mixed in so you can see autospace and kinsoku behavior before clicking OK.',
      'New ParagraphFormat Tiptap extension stores all the dialog\u2019s state as paragraph attributes (data-* attrs + inline style) so values round-trip through save / load / export cleanly. Lives next to the existing Indent and LineHeight extensions, doesn\u2019t collide with them \u2014 the Tab+Shift-Tab indent ladder and the toolbar line-spacing dropdown still work exactly as before.',
      'Footer matches Word: Tabs\u2026 and Set As Default sit on the left as disabled placeholders (Tabs\u2026 is a v0.6.0 sub-dialog, Set As Default lands in v0.5.9+ once style storage is in), Cancel and OK on the right. Animation polish, drag-resize, and the rest of the dialog\u2019s motion details are parked for v0.5.9 \u2192 v0.5.99.',
    ],
  },
  {
    version: '0.5.72',
    date: '2026-05-07',
    tagline: 'The update flow stops fighting itself. One toggle, one button, one mobile-style green badge on the Settings gear that tells you exactly how many releases you\u2019ve missed.',
    changes: [
      'Mobile-style update badge on the Settings gear. When a release newer than the one you have lands, the gear shows a small green pill with the number of releases between yours and latest \u2014 the same way iOS and Android show app-icon notification counts. One release behind shows \u201c1\u201d, three behind shows \u201c3\u201d, way-too-many behind shows \u201c99+\u201d. Tooltip on the gear says how many are pending. The badge replaces the previous undifferentiated green dot.',
      'Auto-download & install toggle removed. The two-toggle setup let the main process and the renderer race for who fired the download first \u2014 with the wrong combination, the manual \u201cDownload New Update\u201d button felt inert because the main process had already silently grabbed it. Updates are now strictly user-driven: the launch check is silent and just populates the badge; clicking Check for Updates runs the scan animation, auto-downloads in the background if a newer release is found, and waits for you to click Install & Restart. Nothing installs without your okay.',
      'Check for Updates is now a single pipeline. Scan animation \u2192 (if newer found) installer downloads to disk \u2192 \u201cInstall & Restart\u201d action button lights up. No more clicking Check, then waiting, then clicking Download separately, then waiting again, then clicking Install. One button starts the chain; the only second click you make is the explicit install confirmation.',
      'Diagnostic panel cleaned up. Removed the Auto-install line since the toggle no longer exists. The Last error / Updater mod / Dev mode lines all stay so support tickets still have everything they need.',
    ],
  },
  {
    version: '0.5.71',
    date: '2026-05-07',
    tagline: 'Spread and Single now show the same document, and the Side-by-Side spread slides between pages like Word — including auto-following the cursor onto the next page when you fill the current one.',
    changes: [
      'Format preserved across mode switches. Switching between Single View and Side-by-Side used to silently drift the document because the two modes wrote into separate stores (`content` vs `pages[]`). Both stores are now mirrored on every keystroke, so the doc you see in Spread is the exact same doc you see in Single — same paragraphs, same indents, same everything. Whichever mode you were just typing in is the canonical source.',
      'Side-by-Side now slides between spreads like Word. Replaced the old swap-positioning hack (which jammed the off-screen pages at left:-99999) with a single horizontal strip that translates with a 320ms cubic-bezier(0.22, 0.61, 0.36, 1) ease — the same pacing Word uses for its page transitions. Off-screen spreads stay mounted so the overflow controller can keep measuring and migrating in the background.',
      'Caret follows you onto the next page. When you type past the bottom of the current page and overflow spawns a new page, the cursor now jumps to that new page at its start — and the spread auto-advances to show it. No more typing into the void on page 1 while the new page sits invisible on the right side of spread 2. Same logic when you click into a different page: the spread containing that page slides into view automatically.',
    ],
  },
  {
    version: '0.5.7',
    date: '2026-05-07',
    tagline: 'Pagination that actually paginates. Pages spawn automatically when you fill one, blocks reflow back when you delete — no more “+ Add page”, no more text clipping into the void.',
    changes: [
      'Overflow-driven pagination. Type past the bottom of a page and the next paragraph migrates onto a fresh page automatically. Delete a page\'s worth of text and content reflows back from the following page to fill the room. Each page is still its own Tiptap editor under the hood — the new piece is a controller that watches every page\'s height and rebalances at top-level block boundaries (paragraphs, headings, lists, blockquotes, etc.).',
      'No more “+ Add page”. The dashed Add-page tile is gone from Side-by-Side, and the trailing phantom spread that existed only to host that tile is gone too. Pages spawn implicitly when content overflows.',
      'Side-by-Side always fits the viewport. The spread auto-scales so both facing pages fit on screen at any window size — no more vertical scroll inside a spread. Wheel and arrow keys page between spreads, just like before.',
      'Single View now paginates too. View → Multiple Pages with Vertical movement is the new paginated single-page experience: stacked page frames with overflow rebalancing between them. View → One Page still gives you the v0.5.0 continuous-scroll layout if that\'s what you prefer.',
      'Corner brackets inverted to match Word\'s print-layout cropmarks. The L-shaped marks now sit AT the writable-area corners with arms extending outward into the margin, not inward into the writable area. (Per the OTHER_SS screenshot you flagged.)',
      'Text now starts at the top-left writable corner, Word-style. The page wrapper was double-applying the margin padding (once on the page-frame, again on the editor wrapper), pushing text ~96px below the top brackets and giving short paragraphs a centered look. Removed the duplicate padding so text snaps to the writable-area top-left and fills downward like every other word processor.',
      'Paste keeps you on the same line. Default Tiptap pastes any HTML containing a block element (which is most clipboard payloads from browsers, docs, and email) as a brand-new paragraph, breaking your sentence onto a new line. Single-block paste content is now unwrapped and inserted inline at the cursor; multi-paragraph pastes still come in as proper paragraphs.',
      'Honest scope note: this is the first cut of overflow-driven pagination. Migration happens at top-level block boundaries, so a single paragraph that\'s longer than a page can still visibly overflow its frame until you break it (the controller can\'t safely split a paragraph mid-sentence yet). Caret may jump after a migration completes — if you typed at the end of page 1 and the paragraph migrated to page 2, the caret follows the content but you\'ll see a brief blink. These edges will get polished in 0.5.7.x patches as real-world docs surface them. The real flow-pagination rewrite (one editor across all pages) is parked for 0.6.0.',
    ],
  },
  {
    version: '0.5.3',
    date: '2026-05-06',
    tagline: 'The visible progress card now shows up for manual checks too — Check for Updates and Download New Update finally pop the same toast the auto path uses.',
    changes: [
      'v0.5.2 only surfaced the bottom-right progress card when auto-install was on. Manual flows still buried the action on the Update tab — if you weren\'t looking, you were guessing. v0.5.3 closes that gap: clicking Check for Updates or Download New Update now arms the same card so you actually see what\'s happening.',
      'Manual mode adds a Download button on the available phase since the main process doesn\'t auto-fire the download in that mode. Click it and the card transitions to the real percent bar exactly like the auto path, then to Install Now when it\'s done.',
      'Card stays silent when auto-install is OFF and you haven\'t clicked anything. No drive-by pop-ups when the app detects a release on its own — you only see the card if you opted in by clicking, or if auto-install is on.',
      'Dismissing the card disarms manual mode (and pins per-version dismissal), so closing the toast doesn\'t make it bounce back on the next state tick. Click Check again to re-arm.',
    ],
  },
  {
    version: '0.5.2',
    date: '2026-05-06',
    tagline: 'Auto-install stops being a ghost. When a new release lands and you have auto-install on, you now actually see the download happening — progress card, percent bar, and an “Install now” button when it finishes.',
    changes: [
      'New bottom-right progress card surfaces the auto-install flow in real time. Previously the main process silently fired downloadUpdate() in the background and the only indicator was a status line on the Update tab in Settings — you\'d only spot it if you happened to be there. Now you get a non-blocking card that walks through detected → downloading → ready, with a real percent bar fed by the existing download-progress events.',
      '“Install now” button on the card once the download finishes — lets you land the update mid-session instead of waiting for next launch. “Later” just dismisses the card and the existing 10-second pending-install countdown still fires when you reopen the app, so nothing is lost either way.',
      'Per-version dismissal: closing the card for v0.5.3 won\'t pop it back open every time the state ticks. A new release with a different version will show the card again.',
      'Card stays out of the way — 360px wide, bottom-right, backdrop-blur, doesn\'t block typing. Manual checks (auto-install off) are unchanged: those flows still drive the Update tab in Settings.',
    ],
  },
  {
    version: '0.5.1',
    date: '2026-05-06',
    tagline: 'v0.5.0 follow-ups — tabs switch again, the Hub stops gaslighting you about "no canvases yet", the ruler bar fits the page, and side-to-side mode actually fits on screen.',
    changes: [
      'Tab switching is unstuck. The route-sync effect was treating the URL as the unconditional source of truth, so clicking another tab snapped activeId back. Now activeId wins after first mount and the URL follows it.',
      'Canvas Hub recent grid: stopped hiding canvases that were already open in tabs. Freshly-created canvases (which always open in a tab) used to disappear from "Recent" entirely — now they stay visible with a tiny “Open” badge so you can see what\'s already loaded.',
      'Ruler bar finally measures itself correctly. The post-Tiptap measure pass ran once on mount before the editor had laid out, so contentWidth stayed at 0 forever and the ruler collapsed to a thin sliver. Now it re-measures whenever the active editor swaps and retries with rAF until the editor has real geometry. Resizes the window properly too.',
      'Side-to-side mode now respects the zoom slider. The spread used to render raw 1632×1056 px with no scaling, blowing past smaller viewports and stretching pages flush to the edges with no padding. Now it scales like vertical mode does, keeps a chalkboard gutter around the spread, and lets you scroll if you zoom in past the viewport.',
      'Default zoom for side-to-side dropped from 125% → 100%. The 125% pick was tuned for the old Quill spread; the Tiptap spread is rendered at honest US-Letter dimensions and already fills the chalkboard, so 125% was clipping the right page. You can still pick 125% (or any zoom) yourself — it\'s just no longer the auto-applied default when you swap modes.',
    ],
  },
  {
    version: '0.5.0',
    date: '2026-05-06',
    tagline: 'Quill is gone — Tiptap takes the canvas. Both pages in side-to-side are now typeable, and you can finally jump back to the Canvas Hub from inside an open canvas.',
    changes: [
      'Quill → Tiptap. The whole Canvas editor is now Tiptap-based. Existing canvases load and migrate their HTML on first open — bold/italic/headings/lists/alignment/indents/font size/line height all carry over.',
      'Side-to-Side: both pages are now typeable. Each page is its own independent Tiptap editor, and a dashed "Add page" tile sits at the next slot when you\'re ready for more. The earlier "page full" chip is retired — just keep writing on the next page.',
      'Vertical mode: visual page-frame overlays now grow with your content (instead of three fixed phantom pages). Single-page mode also stays clean and centered.',
      'New "Canvas Hub" home button sits before the tabs. One click drops you back to the landing screen — your open tabs stick around so you can hop back in anytime.',
      'Toolbar formats are unchanged: Bold/Italic/Underline/Strike, headings, lists, blockquote, code block, alignment, indent in/out, font size, line spacing, link, divider — all wired through to the new editor.',
      'Tab / Shift-Tab still inserts a literal tab and removes the preceding tab. Shipped as a proper Tiptap keymap extension this time, not a DOM-level capture-phase hack.',
      'Honest scope note: independent pages, not a real cross-page text-flow extension. Vertical mode is one continuous editor with visual page overlays; side-to-side has N independent editors. The earlier "phantom flow" / "page full" copy referencing a v0.5.0 flow extension is gone because that\'s not what shipped.',
    ],
  },
  {
    version: '0.4.55',
    date: '2026-05-06',
    tagline: 'Side-to-side now scrolls vertically when you zoom past fit, and pasting no longer flickers.',
    changes: [
      'Side-to-Side mode used to clip both top and bottom of the spread when zoom went above the auto-fit (which the new 125% default did by design). Now the viewport switches to vertical scroll above 100% so you can actually reach the bottom of a tall page.',
      'Pasting into the Canvas no longer briefly shows the pasted text on the next line before snapping back. Disabled Quill\'s post-paste visual-match pass that was causing the ghost render.',
    ],
  },
  {
    version: '0.4.52',
    date: '2026-05-06',
    tagline: 'Canvas bug squash \u2014 dropdowns now sit on top, multi-page view centers properly, side-to-side defaults to a comfier 125% zoom, and full pages stop expanding.',
    changes: [
      'Font Size and Line Spacing dropdowns now portal to the document body instead of fighting the page surface for z-index. They appear in front of the editor where they belong.',
      'Multi-page (Vertical \u00b7 Multiple) layout now centers pages horizontally at every zoom level. The 100/zoom% width hack was pinning stacks to the right edge below 100% zoom.',
      'Side-to-Side mode now defaults to 125% zoom when you switch into it, and snaps back to 100% on the way to Vertical. You can still tweak it from the View menu.',
      'Side-to-Side: when a page is full of text, the live page now clips at the page bottom with a soft fade and a tiny "page full" chip instead of scrolling internally. True cross-page text flow is still on the v0.5.0 (Tiptap) ticket \u2014 this is the honest stopgap.',
    ],
  },
  {
    version: '0.4.51',
    date: '2026-05-06',
    tagline: 'Auto-install is now visible \u2014 a 10s countdown on next launch with a chalkboard splash on the way back. Manual checks now show a scan animation.',
    changes: [
      'When Auto-download & Install is on and a new version was downloaded in the background, the next launch now shows a centered countdown modal that ticks down from 10s before installing. No more silent install-on-quit confusion.',
      'New chalkboard splash on every launch \u2014 Quillosofi wordmark in Oldenburg with a soft fade-in and a tiny spinner. About 1.6s. Just a nicer way to land in the app.',
      'When Auto-install is OFF, clicking Check for Updates now plays a ~2s scan progress bar before resolving. The button no longer feels inert while the check runs.',
      'Pending-install marker is persisted to userData (pending-install.json) so the countdown survives a crash or force-quit between download and the next launch.',
    ],
  },
  {
    version: '0.4.50',
    date: '2026-05-06',
    tagline: 'Pinned/Favorites view is now a proper card grid — Spaces look like canvases & sheets, and Canvases finally show up in the Canvases section.',
    changes: [
      'Pinned spaces now render as cards in a grid, matching the canvas and spreadsheet cards. No more wide thin row stuck in the middle of the page.',
      'The Canvases section in the Pinned/Favorites view now actually shows your pinned and favorite canvases — the search bar / sort / view-switcher toolbar that was hijacking the section is hidden in this view.',
      'Hover a space card to favorite/unpin/pin it inline (mirrors the hover actions on canvas and sheet cards).',
    ],
  },
  {
    version: '0.4.49',
    date: '2026-05-06',
    tagline: 'Spaces settings simplified — Instructions/Sources/Files/Memory tabs removed (they were AI leftovers). Pinned view now shows Canvases first, then Spaces, then Spreadsheets.',
    changes: [
      'New Space and Edit Space dialogs are now a single clean form — name, description, emoji. Done.',
      'Removed the Instructions, Sources, Files, and Memory tabs from the Space settings dialog. Those were AI-era features and have no place in pure-writing Quillosofi.',
      'Existing spaces keep their old AI-era data on disk untouched (system_prompt, links, files, memory) — the dialog just doesn\u2019t expose it anymore.',
      'Pinned and Favorites view in Quillibrary now lists Canvases first, then Spaces, then Spreadsheets. (Was Spaces \u2192 Canvases \u2192 Spreadsheets before.)',
    ],
  },
  {
    version: '0.4.48',
    date: '2026-05-06',
    tagline: 'Spaces moved into Quillibrary. The rail Spaces button is gone, and Spaces can now be pinned and favorited just like canvases.',
    changes: [
      'Spaces are now a Quillibrary feature, not a top-level rail tab. Open Quillibrary, find Spaces in the left sidebar.',
      'New + button next to the SPACES header in Quillibrary opens the New Space dialog.',
      'Spaces can be pinned and favorited — right-click any space in the sidebar (or hover the row in Pinned/Favorites view) to toggle.',
      'Pinned spaces float to the top of the SPACES section in the Quillibrary sidebar.',
      'The Pinned and Favorites filters now show matching Spaces alongside canvases and sheets.',
      'Removed the Grid icon Spaces button from the SpaceRail. Old /spaces URLs redirect to /quillibrary, so nothing breaks.',
      'Removed the orphaned SpacesGrid component now that the dedicated /spaces page is gone.',
    ],
  },
  {
    version: '0.4.47',
    date: '2026-05-06',
    tagline: 'Hotfix — v0.4.46 shipped with a missing Menu icon import that crashed the whole render. Sorry. Fixed.',
    changes: [
      'Re-imported the Menu icon in Layout.jsx. v0.4.46 had it accidentally removed during the AI rip cleanup, which threw `ReferenceError: Menu is not defined` on first render — leaving the window as a blank chalkboard with no UI on top.',
      'No other behavior changes. If v0.4.46 worked for you somehow, v0.4.47 is functionally identical.',
    ],
  },
  {
    version: '0.4.46',
    date: '2026-05-06',
    tagline: 'The Pure Writing Refactor — the entire AI/chat layer is gone, Spaces revamped as pure writing organisation.',
    changes: [
      'Surgically removed the entire AI/chat layer. No more Chat page, Research page, Settings page (the orphaned one), AI Settings modal, Bot Persona, API Key tab, system prompts as prompts, command picker, message canvases, or LLM caller. Quillosofi is now a pure writing app.',
      'Spaces revamped end-to-end. The Space view no longer lists conversations — it shows the canvases inside that space, plus your reference links, attached files, and “Notes” (formerly the system_prompt field, repurposed as plain notes).',
      'New “New canvas in this space” button replaces the old “New chat in this space” button. Spaces are now writing organisation tools, not chat folders.',
      'Custom Dictionary stayed — but the “AI context pin” is now just a plain Star. Pinned words are renamed to Starred. Same data field under the hood, no more AI-context-injection language anywhere in the UI.',
      'Right-click context menu in canvases lost the “Add + Pin to AI context” entry. Plain “Add to Dictionary” remains.',
      'Stats panel rebuilt around writing: canvas count, sheet count, and a recent canvases list. The conversations stat, recent chats list, and AI quick-toggle row are gone.',
      'Sources Vault stays as a manual-entry tool — no auto-cite, no AI-generated citations, just a place to track sources you add yourself.',
      'Import/Export rewritten to handle writing artifacts only: canvases, spreadsheets, project spaces, attached files, and your custom dictionary. Old chat-era exports won’t round-trip; new format is version 2.0.',
      'Removed orphaned Stripe dependencies (@stripe/react-stripe-js, @stripe/stripe-js) that had been hanging around since v0.4.45 when the Upgrade tab became the Donate tab.',
      'About sections in Settings and the Quillosofi Centre rewritten around what’s actually here: Canvas, Page Setup, Spreadsheets, Project Spaces, Custom Dictionary, Custom Fonts, Theme Customization, and Privacy First.',
    ],
  },
  {
    version: '0.4.45',
    date: '2026-05-04',
    tagline: 'Settings → Upgrade is now Settings → Donate. Real Ko-Fi link, no fake pricing tiers.',
    changes: [
      'Replaced the placeholder “Free / Pro / Ultra” Upgrade tab with a proper Donate tab. Quillosofi is free and stays free — no paywalls, no subscriptions.',
      'New Donate tab explains exactly where support goes: keeping quillosofi.com on Spaceship (domain + hosting renewal) and buying time to ship features. No vague “support this app” nonsense.',
      'Direct Ko-Fi button (ko-fi.com/alarkiusej) opens via shell.openExternal so the desktop window doesn’t navigate away.',
      'Tab icon swapped from ⚡ lightning to 🤍 heart, label is now just “Donate”.',
    ],
  },
  {
    version: '0.4.44',
    date: '2026-05-04',
    tagline: 'Friendlier update-check error — the wall of red electron-updater stack traces is gone.',
    changes: [
      'The “Update check failed” red panel is now a soft amber notice with a Rick Astley-flavoured nudge to try again in ~10 minutes (the most common cause is CI still building a freshly-pushed release).',
      'When the underlying error looks like a fresh-tag 404 on latest.yml, the notice adds a one-line explanation. Otherwise it just says try again later.',
      'Full raw error payload still lives in the Diagnostic panel below — nothing was thrown away, just hidden behind a click for support-ticket use.',
    ],
  },
  {
    version: '0.4.43',
    date: '2026-05-04',
    tagline: 'Tiny polish — dropped the “Start writing…” placeholder on Canvas. Blank pages stay blank.',
    changes: [
      'Removed the “Start writing…” ghost text from empty Canvas editors. The blank-state pseudo-element is gone, so a fresh page is just a clean page.',
    ],
  },
  {
    version: '0.4.42',
    date: '2026-05-04',
    tagline: 'No more stealth updates — post-update toast surfaces version jumps, plus a heads-up chip on the auto-install toggle.',
    changes: [
      'New post-update toast (bottom-right): on first launch after an auto-install, Quillosofi tells you which version you came from and which one you’re on, with a “See what’s new” link straight to the Update tab.',
      'Settings → Update → Auto-download & install now shows a small amber heads-up chip when enabled, so you know future updates will apply silently on next launch.',
      'The toast and the existing green dot on the Settings gear share the same one-shot signal — dismissing either clears both.',
    ],
  },
  {
    version: '0.4.40',
    date: '2026-05-04',
    tagline: 'Side-to-Side polish — pages fit the viewport, mouse wheel flips spreads, and Letter trims breathe.',
    changes: [
      'Side to Side now auto-fits the spread to the viewport height (Word-style) so vertical scrolling is gone — no more pages running off the bottom.',
      'Mouse wheel over the chalkboard or phantom pages now flips spreads horizontally, just like Word’s Side to Side mode. (Wheel inside the live editor still scrolls text normally.)',
      'Letter, Legal, and other large trims now have proper chalkboard breathing room on the left and right edges in Vertical view — page edges no longer kiss the sidebar.',
      'Live page in Side to Side is height-capped to one paper sheet; the editor scrolls internally instead of stretching the page off-screen.',
    ],
  },
  {
    version: '0.4.38',
    date: '2026-05-04',
    tagline: 'Visual page-frame pagination + Page Setup — Canvas finally looks like a real page (or a real book spread).',
    changes: [
      'New View button in the Canvas toolbar (top-right) — popover with Page Movement (Vertical / Side to Side), Show (One Page / Multiple Pages), Zoom (50–200%), and Page Setup….',
      'Vertical / One Page: the editor now sits on a real white paper sheet with corner-bracket margin guides and a page-number badge.',
      'Vertical / Multiple Pages: phantom pages stack below page 1 (visual only — real text flow lands in v0.4.50 with the Tiptap migration).',
      'Side to Side: book-spread layout with a verso phantom page on the left and the live recto on the right. Spine seam, nav arrows, and a spread indicator at the bottom.',
      'New Page Setup dialog (Word-style) — Margins tab (top/bottom/left/right/gutter, Portrait/Landscape, Mirror Margins for binding), Paper tab (Letter, Legal, A4, A5, B5, Tabloid, Executive, KDP trim sizes 5×8 / 5.25×8 / 5.5×8.5 / 6×9 / 6.14×9.21 / 7×10, plus Custom). Mini live preview, Reset to defaults, Set As Default.',
      'Per-canvas page setup persists to localStorage; Set As Default seeds new canvases with your preferred trim + margins.',
      'Ruler now snaps to the active page width and respects the chosen left/right margins (and inside/outside flips when Mirror Margins is on for verso pages).',
    ],
  },
  {
    version: '0.4.37',
    date: '2026-05-04',
    tagline: 'Auto-update fix — the Windows installer no longer chokes on \'Failed to uninstall old application files\'.',
    changes: [
      'Bumped electron-builder 24.13.3 → 26.0.20 to pick up the fix for the regression in 24.13.2 that mis-detected the app as running and aborted the uninstall step with error code 2.',
      'Disabled differentialPackage — the patch-based update path was contributing to the same uninstaller failure. Each update is now a clean full install.',
      'Added a postinstall step that appends `CRCCheck off` to electron-builder\'s NSIS template, defusing the integrity check that fired the error in the first place.',
      'CI Node version bumped 20 → 22 (required by the new electron-builder).',
    ],
  },
  {
    version: '0.4.36',
    date: '2026-05-04',
    tagline: 'Tab-close fix — the X button on editor tabs actually closes them now.',
    changes: [
      'Fixed: clicking the X on an inactive tab did nothing, and closing the only/active tab popped it right back open. Both were aftershocks of the v0.4.35 route-precedence sync — the URL still pointed at the closed tab so the effect reopened it. Hub now hops the URL to a fallback tab (or the /canvas landing page when the last tab closes).',
      'Inactive-tab X is now always visible instead of fading in on hover — less guesswork, easier to aim at.',
      'Close button switched to onMouseDown so it can\'t lose a focus race with the row\'s click-to-activate handler.',
      'Same fixes applied to the Sheets editor hub.',
    ],
  },
  {
    version: '0.4.35',
    date: '2026-05-04',
    tagline: 'Bugfix — Canvas (and Sheets) editor no longer ping-pongs when swapping documents.',
    changes: [
      'Fixed an infinite render loop when opening a different canvas from Quillibrary while one was already open. The hub had two URL-sync effects that fought each other when the route id and the persisted lastOpen id disagreed — effect 1 set active=B, effect 2 immediately yanked the URL back to A, repeat forever. Merged them into a single effect with the route as the source of truth.',
      'Same fix applied preemptively to the Sheets editor hub (same pattern, same latent bug).',
    ],
  },
  {
    version: '0.4.34',
    date: '2026-05-03',
    tagline: 'Ruler polish — proper Word ⌐ Left Tab glyph, locked indent markers, new Right Indent triangle.',
    changes: [
      'Left Tab stop glyph now renders as a proper Word-style ⌐ shape — vertical bar on the left, foot extending right at the bottom (was mirrored before).',
      'Hourglass indent markers (▽ first-line, △ hanging, ▭ left) are now locked in place. Tab key no longer drags them around.',
      'Tab key now inserts a literal tab character (just like Word) instead of mutating the paragraph indent. CSS tab-size: 4 makes it render as visible spacing.',
      'New Right Indent marker (◁) at the right margin — draggable like the left side, snaps to 4px increments. Driven by a new padding-right block-level format.',
    ],
  },
  {
    version: '0.4.33',
    date: '2026-05-03',
    tagline: 'Alt-toggle native menu bar is now sticky — stays open until you press Alt again.',
    changes: [
      'The hidden File / Edit / View / Window / Help menu bar (yes, that one Alaria found by accident) is now a deliberate toggle instead of a flicker. Press Alt to reveal it, press Alt again to dismiss it. Clicking elsewhere no longer closes it.',
      'Implementation: intercepts bare Alt keydown via Electron\'s before-input-event in the main process and drives setMenuBarVisible() ourselves — bypassing Electron\'s default “auto-hide on blur” behavior.',
    ],
  },
  {
    version: '0.4.32',
    date: '2026-05-03',
    tagline: 'Three independent ruler markers — first-line, hanging, and left indent — just like Word. Tab no longer drags the whole stack.',
    changes: [
      'Ruler now has THREE separately-draggable markers: ▽ top wedge = first-line indent, △ middle wedge = hanging indent, ▭ bottom slab = left indent. Mirrors Microsoft Word\'s behavior exactly.',
      'Drag TOP → only the first line moves (sets text-indent in em). Drag MIDDLE → lines 2+ shift while the first-line marker holds its absolute position. Drag BOTTOM → entire paragraph slides; top + middle travel together.',
      'Bug fix: Tab key no longer drags the top marker around. Tab only updates the left indent now, so the first-line wedge stays put unless you drag it yourself.',
      'New Quill block format `text-indent` registered globally so first-line indents persist across save/load and export.',
      'Marker drag handlers snap text-indent to the nearest 0.25em for cleaner increments.',
    ],
  },
  {
    version: '0.4.31',
    date: '2026-05-03',
    tagline: 'Tab key REALLY indents now (DOM capture) + Word-style monochrome ruler with draggable tab stops.',
    changes: [
      'Tab / Shift-Tab indent finally works for real. Earlier attempts via Quill\'s keyboard module kept losing to built-in Tab handlers; switched to a DOM-level keydown listener on .ql-editor in the capture phase, which fires before Quill ever sees the keystroke. Cap 8 levels, lists + code-blocks excluded.',
      'Ruler restyled to match Word: monochrome light-gray inset strip, smaller graduated ticks (1/8” / 1/4” / 1/2” / 1”), white digit labels, dimmed margin shading. No more pink and yellow.',
      'Indent marker is now a Word-style hourglass (top wedge + bottom wedge) instead of a single triangle. Drag the bottom wedge to set the active paragraph\'s indent.',
      'Tab stops: click the bottom strip of the ruler to drop a stop, then DRAG it to wherever you want — just like Word. Right-click or double-click any stop to remove it.',
      'Click sensitivity fixed — stops only spawn in the bottom 60% of the ruler height, never within 8px of an existing marker, never on accidental tick-area clicks.',
      'Tab stop glyphs are the Word L-shape in white, with a dark hairline stroke for legibility on any background.',
    ],
  },
  {
    version: '0.4.30',
    date: '2026-05-03',
    tagline: 'Outline rail glow-up + Word-style ruler bar with draggable indent and tab stops.',
    changes: [
      'Outline navigator no longer floats over your text. Lives in a persistent 36px gutter on the left edge of the Canvas — hover-tooltip toggle, expands to the full panel when opened.',
      'When collapsed, the gutter shows a subtle vertical “N headings” label so you know how many anchors are waiting on the other side.',
      'NEW: Ruler bar above every Canvas editor. Word-style numbered scale with major + minor tick marks, dimmed margin shading, and live measurement that follows your editor width.',
      'Drag the ▲ marker on the ruler to set the active paragraph’s left indent — maps to the same 0.5in / 3em steps as the toolbar Indent buttons (cap 8 levels). The marker tracks selection in real time.',
      'Click empty ruler space to drop a tab-stop marker (Word-style L glyph). Click an existing stop to remove it. Stops persist per-canvas in local storage.',
      'Custom Quill tab-jumping to those stops lands with the v0.5 Tiptap rewrite — today the ruler delivers the visual layout metaphor + the indent control.',
    ],
  },
  {
    version: '0.4.29',
    date: '2026-05-03',
    tagline: 'Tab key actually indents now — v0.4.26 binding finally wins the keyboard race.',
    changes: [
      'Tab → indent / Shift-Tab → outdent on Canvas paragraphs now actually fires. Previous static binding was getting pre-empted by Quill\'s built-in Tab handler. Bindings now register imperatively after the editor mounts so they jump to the front of the keyboard chain.',
      'Lists keep their Tab nesting behavior — we only intercept Tab on plain paragraphs, so bulleted/numbered lists still indent like Word.',
      'Indent caps at 8 levels, outdent floors at 0, same as the toolbar buttons.',
    ],
  },
  {
    version: '0.4.28',
    date: '2026-05-03',
    tagline: 'Outline rail moved to the left side of Canvas — where navigation belongs.',
    changes: [
      'The collapsible Outline / header navigator now lives on the LEFT side of the Canvas, next to the editor — not the right. Reads like every IDE and word processor on earth.',
      'Toggle button (when collapsed) sits in the top-left corner of the writing area now. Hide chevron points left when the rail is open.',
    ],
  },
  {
    version: '0.4.27',
    date: '2026-05-03',
    tagline: 'Tiny green dot says hi after every fresh update.',
    changes: [
      'After the app restarts on a new version, a tiny green dot pops up on the Settings gear in the rail and on the Update tab inside Settings — so you actually notice you got a new build.',
      'Open the Update tab once and the dot dismisses itself. Won\'t come back until the next version bump.',
      'Quiet on first-ever install — only fires when there\'s a real version change to celebrate.',
    ],
  },
  {
    version: '0.4.26',
    date: '2026-05-03',
    tagline: 'Word-style toolbar wins on Canvas — font size, alignment, line spacing, indent, outline.',
    changes: [
      'New font-size dropdown on the Canvas toolbar (12 / 14 / 16 / 18 / 20 / 24 / 32 / 48 px) — select text and resize.',
      'Alignment cluster: Left / Center / Right / Justify, four crisp toolbar buttons.',
      'Line spacing dropdown: 1.0 / 1.15 / 1.5 / 2.0 / 2.5 / 3.0 — applied per-block, just like Word.',
      'Indent in / out buttons — plus the Tab key indents and Shift-Tab outdents the current paragraph (max 8 levels). No more Tab jumping out of the editor.',
      'New collapsible Outline rail (right side of Canvas) auto-lists every H1/H2/H3 in your document. Click any heading to scroll there. Hidden by default — hit the tree icon top-right to show it.',
      'Toolbar reskinned to chalk palette — translucent panel with chalkboard texture bleeding through, chalk-yellow active state.',
    ],
  },
  {
    version: '0.4.25',
    date: '2026-05-02',
    tagline: 'OpenRouter key locks in once — toggle AI off/on without re-pasting.',
    changes: [
      'Once you save your OpenRouter API key, it stays in this device\'s local data forever and the input field locks down. Flipping AI off and back on pulls the same key automatically — no more re-pasting every session.',
      'Replaced the trash button with a small "Replace key" link for the rare case your OpenRouter key actually rotates. The previous key stays active until you confirm the new one.',
      'Locked input shows a lock icon and masked preview so you can confirm what\'s saved without ever revealing it again.',
    ],
  },
  {
    version: '0.4.24',
    date: '2026-05-02',
    tagline: 'Killed the obnoxious yellow focus border on canvas editors.',
    changes: [
      'Removed the chalk-yellow focus outline that was wrapping the canvas writing area (and following the cursor around when you clicked into different paragraphs). Vault canvas + chat-side canvas both fixed.',
      'The cursor itself is the focus indicator now — no more highlighter box screaming at you while you write.',
    ],
  },
  {
    version: '0.4.23',
    date: '2026-05-02',
    tagline: 'Theme propagation + Chat welcome cards as sticky notes.',
    changes: [
      'Welcome cards in Chat (Tell me about yourself / Remember my preferences / Help me brainstorm) are now sticky notes — manila, mint, and pink paper with thumbtacks and natural per-card rotation.',
      'Purple-to-violet gradients across Space rail icons, stats panel, and AI settings retinted to chalk-yellow → chalk-pink so they belong on the chalkboard.',
      'Modal backgrounds (Settings, Upgrade, AI Settings, Chat header) now use translucent chalk-deep with backdrop blur — the chalkboard texture bleeds through instead of getting painted over.',
      'Drag placeholder + resize handles on Quillounge are chalk-yellow now, no more leftover purple.',
      'Custom Dictionary AI badges, the spreadsheet "A" indicator, and the Data Security accent retuned to the chalk palette.',
    ],
  },
  {
    version: '0.4.22',
    date: '2026-05-02',
    tagline: 'Thumbtacks pop — no more flat-clipped semicircles.',
    changes: [
      'Thumbtacks now pop above the sticky note top edge instead of being sliced flat against the rounded paper.',
      'Beefed up the tack itself: bigger glossy dome, top highlight, cast shadow grounding it to the paper for proper tactile depth.',
    ],
  },
  {
    version: '0.4.21',
    date: '2026-05-02',
    tagline: 'Chalkboard everywhere + sticky text that actually reads.',
    changes: [
      'Chalkboard texture now extends to the WHOLE app: sidebars, top bar, rails, and mobile overlays. The opaque dark-gray panels that were blocking the texture are gone.',
      'Sticky note text adapts to the paper color — dark ink on Manila / Mint / Pink / Lavender / Aged / Blue, no more white-on-pastel washout.',
      'Inner widget content (Greeting, To Do, Today\'s Prompt, Pinned\u00b7Recent\u00b7Stats) re-themed to ink colors so it reads on every swatch.',
      'Stats / Library / Plugins right-rail cards retinted so they sit on the chalkboard instead of painting over it.',
    ],
  },
  {
    version: '0.4.20',
    date: '2026-05-02',
    tagline: 'Chalkboard redesign — widgets are sticky notes now.',
    changes: [
      'New look: the whole app sits on a deep-green chalkboard surface.',
      'Widgets on Quillounge are now pinned sticky notes — thumbtack at the top, soft paper shadow, slight per-widget tilt.',
      'Per-widget paper colors: Manila, Mint, Pink, Lavender, Aged, Blue. Pick yours from the sticky settings (the slider icon on each note).',
      'Existing widget themes (glass / rose / teal / etc.) auto-map to the closest sticky color so your customizations carry over.',
      'Accent color shifted from purple to chalk-yellow across the app.',
      'Two new font choices in the existing font picker: Oldenburg (slab serif, on-theme) and Instrument Serif (editorial).',
      'Lora is still the default — nothing changes for you unless you switch.',
    ],
  },
  {
    version: '0.4.18',
    date: '2026-05-02',
    tagline: 'Toggling AI off now bounces you back to writing features.',
    changes: [
      'Fixed: turning AI off while parked on Spaces, Research, Chat, or a specific Space left you stranded on a dead view (rail buttons disappeared but the AI-only page kept rendering).',
      'Now redirects to Quillounge (Home) the moment AI flips off from any AI-only route.',
      'Uses replace navigation, so Back doesn\u2019t drop you right back into the orphaned page.',
    ],
  },
  {
    version: '0.4.17',
    date: '2026-05-01',
    tagline: 'In-app changelog viewer.',
    changes: [
      'Added a Changelog panel on the Update tab — mirrors the Diagnostic block: collapsed by default, expands inline.',
      'The panel only shows entries up to your installed version, so older builds never advertise newer features.',
      'Each entry has a tag, date, tagline, and a short bullet list of what changed.',
    ],
  },
  {
    version: '0.4.16',
    date: '2026-04-30',
    tagline: 'Drag-highlight in chat preserved; native double-click selection disabled.',
    changes: [
      'Disabled native double-click word selection inside the chat scroll container.',
      'Drag-highlight follow-up flow still works exactly as before.',
    ],
  },
  {
    version: '0.4.15',
    date: '2026-04-29',
    tagline: 'External links bounce to the OS browser instead of navigating in-window.',
    changes: [
      'Hold-to-launch external link flow now opens in the system default browser.',
      'No more accidentally replacing the app shell with a YouTube tab.',
    ],
  },
  {
    version: '0.4.14',
    date: '2026-04-28',
    tagline: 'Removed Windows tray icon (-245 lines). Tray was blocking the installer.',
    changes: [
      'Tray icon removed entirely on Windows — it was holding a file handle on the .exe and blocking NSIS.',
      'Stealth twin prank button removed from the Update tab; tab is now strictly functional.',
    ],
  },
  {
    version: '0.4.13',
    date: '2026-04-27',
    tagline: 'Don\'t kill the process before NSIS launches.',
    changes: [
      'Resolved race condition where windows were being destroyed before NSIS could launch the installer.',
    ],
  },
  {
    version: '0.4.12',
    date: '2026-04-27',
    tagline: 'Smoother button crossfade + (now-removed) twin prank button.',
    changes: [
      'Action button crossfade duration tuned (200ms → 300ms with proper out/in overlap).',
      'Single morphing action button — no more flash on every state change.',
    ],
  },
  {
    version: '0.4.11',
    date: '2026-04-26',
    tagline: 'Fixed NSIS Error 2 by tearing down lingering processes.',
    changes: [
      'Tore down lingering app processes before quitAndInstall so the installer can grab file locks.',
    ],
  },
  {
    version: '0.4.10',
    date: '2026-04-25',
    tagline: 'Killed the visible button flash on update state changes.',
    changes: [
      'Replaced unmount/remount of the action button with a single morphing button.',
      'Status transitions are now buttery instead of pop-flickery.',
    ],
  },
  {
    version: '0.4.9',
    date: '2026-04-24',
    tagline: 'Updater finally loads — moved electron-updater to dependencies.',
    changes: [
      'Moved electron-updater from devDependencies to dependencies so the packaged app actually has it.',
      'Auto-update is now functional end-to-end on packaged builds.',
    ],
  },
  {
    version: '0.4.8',
    date: '2026-04-23',
    tagline: 'Adaptive Quillounge layout in windowed mode.',
    changes: [
      'Quillounge home dashboard adapts per-breakpoint when the window is resized.',
      'Per-breakpoint widget customization is preserved across launches.',
    ],
  },
  {
    version: '0.4.7',
    date: '2026-04-22',
    tagline: 'Dedicated editor hubs with multi-doc tabs and Resume Last.',
    changes: [
      'Canvas and Sheets each got a dedicated hub with a multi-doc tab strip.',
      'Resume Last reopens what you were on when you quit.',
    ],
  },
  {
    version: '0.4.6',
    date: '2026-04-21',
    tagline: 'Update tab gains its full UX.',
    changes: [
      'Update tab now shows installed version, latest, status, release notes, and preferences.',
      'Diagnostic block surfaces updater state for support tickets.',
    ],
  },
];

// Helpers used by the Update tab.

// Strip a leading "v" if present and return the bare semver.
function normalize(v) {
  if (!v) return '';
  return String(v).replace(/^v/i, '').trim();
}

// Compare two semver strings. Returns -1 / 0 / 1 like Array#sort.
// Only handles MAJOR.MINOR.PATCH which is all we ship; pre-release tags
// (-alpha, -rc.1) compare lexically as a fallback.
export function compareVersions(a, b) {
  const [aMain, aPre = ''] = normalize(a).split('-');
  const [bMain, bPre = ''] = normalize(b).split('-');
  const ap = aMain.split('.').map((n) => parseInt(n, 10) || 0);
  const bp = bMain.split('.').map((n) => parseInt(n, 10) || 0);
  for (let i = 0; i < 3; i++) {
    const ai = ap[i] ?? 0;
    const bi = bp[i] ?? 0;
    if (ai !== bi) return ai > bi ? 1 : -1;
  }
  // Empty pre-release sorts higher than a pre-release of the same MAJOR.MINOR.PATCH.
  if (aPre === bPre) return 0;
  if (!aPre) return 1;
  if (!bPre) return -1;
  return aPre > bPre ? 1 : -1;
}

// Return all changelog entries up through `installedVersion`, newest first.
// If installedVersion is missing or unparseable, return everything (better
// to over-show during dev than leave the panel mysteriously empty).
export function entriesUpTo(installedVersion) {
  const cap = normalize(installedVersion);
  if (!cap) return [...CHANGELOG];
  return CHANGELOG
    .filter((e) => compareVersions(e.version, cap) <= 0)
    .sort((a, b) => compareVersions(b.version, a.version));
}

// v0.5.72 — count releases between `installedVersion` (exclusive) and
// `latestVersion` (inclusive). Drives the mobile-style green pill badge on
// the Settings gear so users see at a glance how many releases they've
// missed. Returns 0 if no update or no changelog entries match.
export function pendingReleaseCount(installedVersion, latestVersion) {
  if (!latestVersion) return 0;
  const installed = normalize(installedVersion);
  const latest = normalize(latestVersion);
  if (!latest) return 0;
  // If installed is unparseable, treat all entries up to latest as pending.
  return CHANGELOG.filter((e) => {
    const v = normalize(e.version);
    if (!v) return false;
    if (compareVersions(v, latest) > 0) return false; // newer than latest, ignore
    if (!installed) return true;
    return compareVersions(v, installed) > 0; // strictly newer than installed
  }).length;
}
