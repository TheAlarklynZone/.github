import { useState, useEffect } from 'react';
import { app } from '@/api/localClient';

const GUEST_START_KEY = 'zetryl_guest_first_visit';
const GUEST_DISMISSED_BANNER_KEY = 'zetryl_guest_banner_dismissed_day';
const IS_DESKTOP = typeof window !== 'undefined' && !!window.quillosofi?.isDesktop;

export function useGuestMode() {
  // Desktop is fully local — never "guest mode" with countdown banners.
  const [isGuest, setIsGuest] = useState(false);
  const [daysElapsed, setDaysElapsed] = useState(0);
  const [firstVisit, setFirstVisit] = useState(null);
  const [loading, setLoading] = useState(!IS_DESKTOP);

  useEffect(() => {
    if (IS_DESKTOP) return; // no guest concept on desktop
    const init = async () => {
      const authed = await app.auth.isAuthenticated();
      if (authed) {
        setIsGuest(false);
        setLoading(false);
        return;
      }

      // Guest: init or read first visit timestamp
      let storedDate = localStorage.getItem(GUEST_START_KEY);
      if (!storedDate) {
        storedDate = new Date().toISOString();
        localStorage.setItem(GUEST_START_KEY, storedDate);
      }

      const start = new Date(storedDate);
      const now = new Date();
      const elapsed = Math.floor((now - start) / (1000 * 60 * 60 * 24));

      setIsGuest(true);
      setFirstVisit(start);
      setDaysElapsed(elapsed);
      setLoading(false);
    };

    init();
  }, []);

  const daysRemaining = Math.max(0, 14 - daysElapsed);
  const isExpired = daysElapsed >= 14;
  const showBanner = isGuest && daysElapsed >= 12 && !isExpired;

  const dismissedDay = localStorage.getItem(GUEST_DISMISSED_BANNER_KEY);
  const isBannerDismissed = dismissedDay === String(daysElapsed);

  const dismissBanner = () => {
    localStorage.setItem(GUEST_DISMISSED_BANNER_KEY, String(daysElapsed));
  };

  return { isGuest, daysElapsed, daysRemaining, firstVisit, isExpired, showBanner: showBanner && !isBannerDismissed, dismissBanner, loading };
}